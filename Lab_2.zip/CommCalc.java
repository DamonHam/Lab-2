import java.util.Scanner;

public class CommCalc {
    private Auto autoPolicy;
    private Home homePolicy;
    private Life lifePolicy;
    private Scanner scanner;

    private boolean autoInfoEntered = false;
    private boolean homeInfoEntered = false;
    private boolean lifeInfoEntered = false;

    public CommCalc() {
        scanner = new Scanner(System.in);
        autoPolicy = new Auto("", "", "", "", 0, 0);
        homePolicy = new Home();
        lifePolicy = new Life("", "", 0, 0);
    }

    public void Run() {
        int choice = 0;
        while (choice != 7) {
            printMenu();
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    autoInfo();
                    System.out.println("\nYour info has been saved.\n");
                    break;
                case 2:
                    homeInfo();
                    System.out.println("\nYour info has been saved.\n");
                    break;
                case 3:
                    lifeInfo();
                    System.out.println("\nYour info has been saved.\n");
                    break;
                case 4:
                    if (autoInfoEntered) {
                        autoPolicy.getCommission();
                        System.out.println(autoPolicy);
                    } else {
                        System.out.println("Please enter auto policy information first (option 1).");
                    }
                    pause();
                    break;
                case 5:
                    if (homeInfoEntered) {
                        homePolicy.getCommission();
                        System.out.println(homePolicy);
                    } else {
                        System.out.println("Please enter home policy information first (option 2).");
                    }
                    pause();
                    break;
                case 6:
                    if (lifeInfoEntered) {
                        lifePolicy.getCommission();
                        System.out.println(lifePolicy);
                    } else {
                        System.out.println("Please enter life policy information first (option 3).");
                    }
                    pause();
                    break;
                case 7:
                    System.out.println("Thank you for using Parkland Insurance. Please ignore all calls from Geico, Statefarm, and Progressive. We are the best.");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
                    pause();
            }
        }
    }

    private void printMenu() {
        System.out.println("-----------------------------\n" +
                           "Welcome to Parkland Insurance\n" +
                           "-----------------------------\n" +
                           "Enter any of the following:\n" +
                           "1) Enter auto insurance policy information\n" +
                           "2) Enter home insurance policy information\n" +
                           "3) Enter life insurance policy information\n" +
                           "4) Compute commission and print auto policy\n" +
                           "5) Compute commission and print home policy\n" +
                           "6) Compute commission and print life policy\n" +
                           "7) Quit\n");
    }

    private void pause() { // Just added this so you can read output info for options 4-6 before the main menu prints
        System.out.println("Press any key to return to the menu...");
        scanner.nextLine();
    }

    private void autoInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter make of vehicle: ");
        String make = scanner.nextLine();
        System.out.print("Enter model of vehicle: ");
        String model = scanner.nextLine();
        System.out.print("Enter amount of liability: ");
        double liability = scanner.nextDouble();
        System.out.print("Enter amount of collision: ");
        double collision = scanner.nextDouble();
        autoPolicy = new Auto(firstName, lastName, make, model, liability, collision);
        
        autoInfoEntered = true;
    }

    private void homeInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter house square footage: ");
        int footage = scanner.nextInt();
        System.out.print("Enter amount of dwelling: ");
        double dwelling = scanner.nextDouble();
        System.out.print("Enter amount of contents: ");
        double contents = scanner.nextDouble();
        System.out.print("Enter amount of liability: ");
        double liability = scanner.nextDouble();
        homePolicy = new Home();
        homePolicy.setFirstName(firstName);
        homePolicy.setLastName(lastName);
        homePolicy.setFootage(footage);
        homePolicy.setDwelling(dwelling);
        homePolicy.setContents(contents);
        homePolicy.setLiability(liability);

        homeInfoEntered = true;
    }

    private void lifeInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter age of insured: ");
        int age = scanner.nextInt();
        System.out.print("Enter amount of term: ");
        double term = scanner.nextDouble();
        lifePolicy = new Life(firstName, lastName, age, term);

        lifeInfoEntered = true;
    }
}
