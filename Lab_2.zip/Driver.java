public class Driver {

    public static void main(String[] args) {
        // Create commission calculator
        CommCalc calc = new CommCalc();

        // Run commission calculator
        calc.Run();
    }
}
